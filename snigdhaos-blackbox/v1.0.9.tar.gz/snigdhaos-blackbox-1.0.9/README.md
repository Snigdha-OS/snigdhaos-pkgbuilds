<h1 align="center">Snigdha OS Blackbox</h1>

![image](https://github.com/user-attachments/assets/4a6b6253-8c09-42f8-bd78-860d0debd371)
